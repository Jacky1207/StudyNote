<!--
    Last modified: 2022-06-27 21:09:12
    Url: https://www.axui.cn
-->
<!DOCTYPE html>
<html>
<head>
   
    <title>常用说明文档框架-AXUI前端框架|斧子框架，面向设计的自主国产前端框架</title>
    <link href="css/ax.css" rel="stylesheet" type="text/css" >
    <link href="css/ax-response.css" rel="stylesheet" type="text/css" >
    <link href="css/main.css" rel="stylesheet" type="text/css">
</head>

<body class="ax-demo-admin">
    <!--主导航-->
    <nav class="ax-flex-col">
        <div class="ax-nav-header">
            <a href="https://www.axui.cn/" target="_blank" class="ax-logo"><img src="https://src.axui.cn/v2.0/public/images/ax-logo.png" /></a>
            <a href="###" class="ax-close-nav ax-iconfont ax-icon-menu-fold"></a>
        </div>
        <div class="ax-flex-block ax-nav-main">
            <div class="ax-nav-search">

                <input type="text" name="" placeholder="关键字..." />
                <a href="###" class="ax-iconfont ax-icon-search"></a>
            </div>
            <ul class="ax-menu ax-style-dot" axMenu data-cookie="axuiadmin001">
                <li>
                    <a href="###"><span class="ax-legend ax-iconfont ax-icon-settings-alt"></span><span class="ax-name">系统配置</span><span class="ax-arrow ax-iconfont ax-icon-right"></span></a>
                    <ul>
                        <li><a href="###"><span class="ax-name">组织架构管理</span></a></li>
                        <li><a href="###"><span class="ax-name">人员管理</span></a></li>
                        <li><a href="###"><span class="ax-name">功能权限管理</span></a></li>
                        <li><a href="###"><span class="ax-name">数据权限管理</span></a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><span class="ax-legend ax-iconfont ax-icon-message-o"></span><span class="ax-name">团队协作</span><span class="ax-arrow ax-iconfont ax-icon-right"></span></a>
                    <ul>
                        <li><a href="###"><span class="ax-name">日历</span></a></li>
                        <li><a href="###"><span class="ax-name">笔记</span></a></li>
                        <li><a href="###"><span class="ax-name">任务看板</span></a></li>
                        <li><a href="###"><span class="ax-name">知识库</span></a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><span class="ax-legend ax-iconfont ax-icon-global"></span><span class="ax-name">监控管理</span><span class="ax-arrow ax-iconfont ax-icon-right"></span></a>
                    <ul>
                        <li><a href="###"><span class="ax-name">注册中心监控</span></a></li>
                        <li><a href="###"><span class="ax-name">服务治理</span></a></li>
                        <li><a href="###"><span class="ax-name">服务监控</span></a></li>
                        <li><a href="###"><span class="ax-name">服务链路跟踪</span></a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><span class="ax-legend ax-iconfont ax-icon-me"></span><span class="ax-name">个人中心</span><span class="ax-arrow ax-iconfont ax-icon-right"></span></a>
                    <ul>
                        <li><a href="###"><span class="ax-name">日志管理</span></a></li>
                        <li><a href="###"><span class="ax-name">好友管理</span></a></li>
                        <li><a href="###"><span class="ax-name">个人资料</span></a></li>
                        <li><a href="###"><span class="ax-name">修改密码</span></a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><span class="ax-legend ax-iconfont ax-icon-power"></span><span class="ax-name">退出系统</span></a>
                </li>
            </ul>
            <!--收缩后的遮罩层，点击可重新展开菜单-->
            <div class="ax-mask"></div>
        </div>
    </nav>
    <div class="ax-nav-overlay ax-hide"></div>
    <!--框架头部-->
    <header class="ax-flex-row">
        <div class="ax-flex-block">
            <div class="ax-breadcrumb"><a href="###">说明文档</a><i class="ax-gutter ax-iconfont ax-icon-right"></i><span>系统API</span></div>
        </div>
        <div class="ax-header-search"><input type="text" name="" placeholder="关键字..." /> <a href="###" class="ax-iconfont ax-icon-search"></a></div>
    </header>
    <div class="ax-space-header"></div>
    <!--头部占位-->
    <!--框架主体-->
    <main id="article">

        <div class="ax-padding">
            <div class="ax-padding">
                <h1>伟大的中国</h1>
            </div>

            <div class="ax-article">
                <blockquote>
                    <p>一千年前的中国已经摆脱前代沉迷于异族的宗教，和以外国宗教为自己国教的状态。一千年前中国自己的宗教道教、儒教大放光芒，远远压过外国，这是国家文化强大民族自信的表现，一千年前的中国人自信得一塌糊涂。</p>
                </blockquote>
                <h2>一、简介</h2>
                <p>　　中国，是以<a href="###">华夏文明</a>为源泉、中华文化为基础，并以汉族为主体民族的多民族国家，通用汉语、汉字，汉族与少数民族被统称为“中华民族”，又自称为炎黄子孙、龙的传人。</p>
                <img src="https://src.axui.cn/v2.0/public/images/full01.jpg" axLightbox/>
                <p>　　中国是世界四大文明古国之一，有着悠久的历史，距今约5000年前，以中原地区为中心开始出现聚落组织进而形成国家，后历经多次民族交融和朝代更迭，直至形成多民族国家的大一统局面。20世纪初辛亥革命后，君主政体退出历史舞台，共和政体建立。1949年中华人民共和国成立后，在中国大陆建立了人民代表大会制度的政体。</p>

                <p>　　中国疆域辽阔、民族众多，先秦时期的华夏族在中原地区繁衍生息，到了汉代通过文化交融使汉族正式成型，奠定了中国主体民族的基础。后又通过与周边民族的交融，逐步形成统一多民族国家的局面，而人口也不断攀升，宋代中国人口突破一亿，清朝时期人口突破四亿，到2005年中国人口已突破十三亿。</p>

                <p>　　中国文化渊远流长、博大精深、绚烂多彩，是东亚文化圈的文化宗主国，在世界文化体系内占有重要地位，由于各地的地理位置、自然条件的差异，人文、经济方面也各有特点。传统文化艺术形式有诗词、戏曲、书法、国画等，而春节、元宵、清明、端午、中秋、重阳等则是中国重要的传统节日。</p>
                <h2>二、词义</h2>
                <p>　　中国一词最早见于西周初年的青铜器“何尊”铭文中的“余其宅兹中国，自之辟民”，同时又以“华夏”、“中华”、“中夏”、“中原”、“诸夏”、“诸华”、“神州”、“九州”、“海内”等的代称出现。</p>
                <p>　　“华夏”一词最早见于周朝《尚书·周书·武成》，“华夏蛮貊，罔不率俾”。 《书经》曰：“冕服采装曰华，大国曰夏”。《尚书正义》注：“冕服华章曰华，大国曰夏”。“华”，是指华丽、兴旺；也有说上古华、夏同音，本一字。《左传》曰：“中国有礼仪之大，故称夏；有服章之美，谓之华。” 华是指汉服，夏指行周礼的大国，故中国有礼仪之邦、衣冠上国之美誉。</p>
                <h2>三、历史</h2>
                <ol>
                    <li>古代史</li>
                    <li>近代史</li>
                    <li>现代史</li>
                </ol>
                <h2>四、地理</h2>
                <ul>
                    <li>中国地势西高东低，山地、高原和丘陵约占陆地面积的67%，盆地和平原约占陆地面积的33%。</li>
                    <li>几百万年前，青藏高原隆起，地球历史上此一重大地壳运动形成了中国的地貌。</li>
                </ul>
            </div>

        </div>

        <footer>
            &#xa9; 2022 <a href="https://www.axui.cn/" target="_self">Axui.cn</a> <a href="https://baike.baidu.com/item/MIT许可证" target="_blank" rel="nofollow">MIT license</a>            <script type="text/javascript" src="https://js.users.51.la/21359227.js" ></script>
        </footer>

    </main>

    <div class="ax-scrollnav-v" id="blockNav"><a href="###" class="ax-close ax-iconfont ax-icon-arrow-right"></a></div>

    <script src="https://src.axui.cn/v2.0/dist/js/ax.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="https://src.axui.cn/v2.0/dist/plugins/scrollnav/scrollnav.min.js"></script>

    <script type="text/javascript" src="https://src.axui.cn/v2.0/dist/plugins/scrollnav/scrollnav.min.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>